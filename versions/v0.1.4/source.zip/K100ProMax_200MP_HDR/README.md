# Redmi K100 Pro Max · 200MP HDR

适用设备为 Redmi K100 Pro Max（songyuan）、Android 17 / HyperOS 4，以及小米原签名系统相机 6.7.000280.0（版本代码 670002800）。v0.1.4 使用 libxposed API 102，支持该 API 的 LSPosed 版本可识别模块。

## 安装与检查

1. 覆盖安装 APK，在 LSPosed 中启用「K100 Pro Max 200MP HDR」，作用域勾选当前用户的系统相机。
2. 打开桌面上的「K100 Pro Max 200MP HDR」，点「检查状态」。首次检查时允许本应用使用 KernelSU 的 Root 权限。
3. 点「打开系统相机」，进入「超清 → 200MP」。如果刚从旧版更新，先在应用信息页强行停止系统相机，再打开相机。返回状态页后会重新检查。
4. 需要排查时点「复制诊断」。面板读取当前版本、已保存的作用域、相机进程和缓存状态。系统日志静默时，仍可以读取模块写入的本地状态。
5. 要恢复原厂行为，在 LSPosed 中关闭模块，再重开相机。

状态页向 LSPosed 服务读取相机作用域和已报告的运行目标。Root 检查以只读方式打开 LSPosed 数据库，按实际列结构查询当前用户的相机作用域。框架数据库缺少开关字段时，状态页仍可显示已保存的相机作用域。模块的应用进程把自己的运行状态写入相机缓存。状态页用 PID 和可用时的进程启动时间判断记录是否来自当前相机进程。

## 如何判断是否生效

| 状态 | 能确认的步骤 |
| --- | --- |
| 系统相机已勾选 | 读取到当前用户已保存的模块开关和作用域 |
| 模块已初始化 | 当前相机进程完成了版本、设备、签名检查并注册了 hook |
| 原厂 Auto HDR 组件已就绪 | 200MP 模式具备原厂 HDR 场景判断的入口 |
| 快门请求带 HDR | 模块从一个高像素快门请求读到厂商 HDR 启用字段 |
| 成片原图与融合信息 | 核对完整 200MP 分辨率以及后处理是否确实启用了 HDR 融合 |

原厂 HDR 组件保留场景判定和原有曝光选择。JPEG 厂商 EXIF 的 `Hdr` 字段可辅助验证。此前的一张 200MP 原图为 16384 × 12288 且标记 `Hdr=off`。v0.1.4 已构建并通过签名和包结构检查，装机注入及实拍融合仍待验证。

## 构建

需要 JDK 17 或以上、Android SDK platform 37、Build Tools 36.0.0 以及 libxposed API 102.0.0 和 libxposed interface 102.0.0 的 `classes.jar`。设置 `JAVA_HOME`、`ANDROID_SDK_ROOT`、`LIBXPOSED_API_JAR`、`LIBXPOSED_INTERFACE_JAR`、`SONGYUAN_KEYSTORE` 和 `SONGYUAN_KEY_PASSWORD_FILE`，使用别名 `songyuan-hdr` 的签名条目。运行 `bash build.sh` 后在 `build/` 获取签名 APK。
