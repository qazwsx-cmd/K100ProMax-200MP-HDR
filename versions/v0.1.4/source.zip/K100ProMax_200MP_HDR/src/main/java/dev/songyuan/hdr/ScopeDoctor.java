package dev.songyuan.hdr;

import android.database.sqlite.SQLiteDatabase;
import android.os.Process;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;

public final class ScopeDoctor {
    static final String OUTPUT_PREFIX = "SONGYUAN_HDR_JSON ";
    private static final File DATABASE = new File("/data/adb/lspd/config/modules_config.db");

    public static void main(String[] args) throws JSONException {
        JSONObject report = new JSONObject();
        int uid = Process.myUid();
        report.put("uid", uid);
        if (uid == 0 && args.length == 2) {
            int user = Integer.parseInt(args[0]);
            report.put("user", user);
            report.put("framework_version", readModuleVersion("zygisk_lsposed"));
            report.put("zygisk_version", readModuleVersion("zygisksu"));
            report.put("framework_daemon", readPids("lspd").toString());
            readScope(user, args[1], report);
            inspectCamera(user, report);
            readRecentLog(report);
            report.put("framework_logs", frameworkLogs());
        }
        System.out.println(OUTPUT_PREFIX + report);
    }

    private static String readModuleVersion(String id) {
        File file = new File("/data/adb/modules/" + id + "/module.prop");
        try (FileInputStream input = new FileInputStream(file)) {
            Properties values = new Properties();
            values.load(input);
            return values.getProperty("version", "");
        } catch (IOException | RuntimeException ignored) {
            return "";
        }
    }

    private static void readScope(int user, String sourceApk, JSONObject report)
            throws JSONException {
        if (!DATABASE.isFile()) {
            report.put("scope", "unavailable");
            report.put("scope_error", "LSPosed 模块数据库不存在或不可见");
            return;
        }
        try (SQLiteDatabase db = SQLiteDatabase.openDatabase(DATABASE.getPath(), null,
                SQLiteDatabase.OPEN_READONLY | SQLiteDatabase.NO_LOCALIZED_COLLATORS)) {
            try {
                ScopeRegistry.read(db, user, sourceApk, report);
            } catch (RuntimeException error) {
                report.put("scope", "unavailable");
                report.put("scope_error", error.getClass().getSimpleName() + " " + error.getMessage());
                try {
                    ScopeRegistry.reportSchema(db, report);
                } catch (RuntimeException ignored) {
                    // The main query error is kept even if schema introspection also fails.
                }
            }
        } catch (RuntimeException error) {
            report.put("scope", "unavailable");
            report.put("scope_error", error.getClass().getSimpleName() + " " + error.getMessage());
        }
    }

    private static void inspectCamera(int user, JSONObject report) throws JSONException {
        int pid = 0;
        for (int candidate : readPids(HdrPolicy.CAMERA)) {
            if (isUserProcess(candidate, user)) {
                pid = candidate;
                break;
            }
        }
        report.put("camera_pid", pid);
        if (pid != 0) {
            report.put("camera_bridge", inspectMaps(pid));
        }

        File statusFile = new File("/data/user/" + user + "/" + HdrPolicy.CAMERA
                + "/cache/" + HdrPolicy.STATUS_FILE);
        if (!statusFile.isFile() || statusFile.length() > 16_384) {
            return;
        }

        try (FileInputStream input = new FileInputStream(statusFile)) {
            Properties status = new Properties();
            status.load(input);
            JSONObject snapshot = new JSONObject();
            for (String key : status.stringPropertyNames()) {
                snapshot.put(key, status.getProperty(key));
            }
            String savedStart = status.getProperty("start_ticks", "");
            boolean live = pid != 0 && Integer.toString(pid).equals(status.getProperty("pid"));
            if (live && !savedStart.isEmpty()) {
                String processStart = StatusJournal.processStartTicks("/proc/" + pid + "/stat");
                live = !processStart.isEmpty() && savedStart.equals(processStart);
            }
            report.put("camera_record_current", live);
            report.put("camera_record", snapshot);
        } catch (IOException | RuntimeException error) {
            report.put("camera_record_error", error.getClass().getSimpleName());
        }
    }

    private static List<Integer> readPids(String processName) {
        List<Integer> pids = new ArrayList<>();
        java.lang.Process child = null;
        try {
            child = new ProcessBuilder("/system/bin/pidof", processName).start();
            try (BufferedReader input = new BufferedReader(new InputStreamReader(
                    child.getInputStream(), StandardCharsets.UTF_8))) {
                String line = input.readLine();
                if (line != null) {
                    for (String value : line.trim().split("\\s+")) {
                        if (!value.isEmpty()) {
                            pids.add(Integer.parseInt(value));
                        }
                    }
                }
            }
        } catch (IOException | NumberFormatException ignored) {
            // An exited process can disappear between collection steps.
        } finally {
            if (child != null) {
                child.destroy();
            }
        }
        return pids;
    }

    private static boolean isUserProcess(int pid, int user) {
        try (BufferedReader reader = new BufferedReader(new FileReader("/proc/" + pid + "/status"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Uid:")) {
                    String value = line.substring(4).trim().split("\\s+", 2)[0];
                    return Integer.parseInt(value) / 100_000 == user;
                }
            }
        } catch (IOException | NumberFormatException ignored) {
            // The process may have exited.
        }
        return false;
    }

    private static String inspectMaps(int pid) {
        try (BufferedReader reader = new BufferedReader(new FileReader("/proc/" + pid + "/maps"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("zygisk_lsposed") || line.contains("/lspd/")) {
                    return "visible";
                }
            }
            return "not_visible";
        } catch (IOException | RuntimeException ignored) {
            return "unavailable";
        }
    }

    private static String frameworkLogs() {
        File[] files = new File("/data/adb/lspd/log").listFiles((dir, name) ->
                (name.startsWith("modules_") || name.startsWith("verbose_")) && name.endsWith(".log"));
        if (files == null) {
            return "";
        }
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        ArrayDeque<String> lines = new ArrayDeque<>();
        for (int index = 0; index < Math.min(files.length, 4); index++) {
            try (RandomAccessFile input = new RandomAccessFile(files[index], "r")) {
                long length = input.length();
                int count = (int) Math.min(length, 256_000);
                input.seek(length - count);
                byte[] tail = new byte[count];
                input.readFully(tail);
                for (String line : new String(tail, StandardCharsets.UTF_8).split("\n")) {
                    if (line.contains(HdrPolicy.TAG) || line.contains(HdrPolicy.MODULE)) {
                        if (lines.size() == 16) {
                            lines.removeFirst();
                        }
                        lines.addLast(files[index].getName() + " " + line.substring(0,
                                Math.min(line.length(), 512)));
                    }
                }
            } catch (IOException | RuntimeException ignored) {
                // A framework log can rotate between listing and reading it.
            }
        }
        return String.join("\n", lines);
    }

    private static void readRecentLog(JSONObject report) throws JSONException {
        ArrayDeque<String> selected = new ArrayDeque<>();
        String cameraPid = Integer.toString(report.optInt("camera_pid"));
        boolean currentEntry = false;
        boolean currentLoad = false;
        boolean currentHookError = false;
        java.lang.Process child = null;
        try {
            child = new ProcessBuilder("/system/bin/logcat", "-b", "all", "-d", "-t", "5000",
                    "-v", "threadtime").start();
            try (BufferedReader input = new BufferedReader(new InputStreamReader(
                    child.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = input.readLine()) != null) {
                    if (line.contains(HdrPolicy.TAG) || line.contains(HdrPolicy.MODULE)) {
                        String[] columns = line.trim().split("\\s+", 6);
                        if (columns.length == 6 && cameraPid.equals(columns[2])) {
                            currentEntry |= line.contains("ENTRY module=" + HdrPolicy.VERSION);
                            currentLoad |= line.contains("MODULE_LOADED module=" + HdrPolicy.VERSION);
                            currentHookError |= line.contains("BOOTSTRAP_HOOK_ERROR");
                        }
                        if (selected.size() == 12) {
                            selected.removeFirst();
                        }
                        selected.addLast(line.substring(0, Math.min(line.length(), 512)));
                    }
                }
            }
        } catch (IOException | RuntimeException ignored) {
            // Scope and camera cache are available even when the system log is muted.
        } finally {
            if (child != null) {
                child.destroy();
            }
        }
        report.put("logs", String.join("\n", selected));
        report.put("camera_entry", currentEntry);
        report.put("camera_module_loaded", currentLoad);
        report.put("camera_hook_error", currentHookError);
    }
}
