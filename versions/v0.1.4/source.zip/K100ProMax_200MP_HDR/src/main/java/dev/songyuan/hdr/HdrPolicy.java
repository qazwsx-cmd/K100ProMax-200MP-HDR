package dev.songyuan.hdr;

final class HdrPolicy {
    static final String VERSION = "0.1.4";
    static final int VERSION_CODE = 5;
    static final String MODULE = "dev.songyuan.hdr";
    static final String CAMERA = "com.android.camera";
    static final String TAG = "Songyuan200HDR";
    static final String STATUS_FILE = "songyuan200hdr-status.properties";
    static final String CAMERA_VERSION = "6.7.000280.0";
    static final long CAMERA_VERSION_CODE = 670002800L;
    static final int SDK_VERSION = 37;
    static final int HIGH_RES_MODE = 175;
    static final int HD_HDR_COMPONENT = 1;
    static final int HD_HDR_REQUEST = 2;

    static boolean isSupportedDevice(String device) {
        return "songyuan".equals(device);
    }

    static boolean is200Mp(int width, int height) {
        return (long) width * height >= 199_756_800L;
    }

    static boolean supported(boolean customPixelProfile, int nativeBits) {
        return customPixelProfile || (nativeBits & HD_HDR_COMPONENT) != 0;
    }

    static boolean activatesHdr(String stockPreference) {
        return "auto".equals(stockPreference) || "on".equals(stockPreference)
                || "normal".equals(stockPreference);
    }
}
