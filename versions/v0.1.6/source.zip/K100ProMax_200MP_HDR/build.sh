#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

: "${ANDROID_SDK_ROOT:?Set Android SDK root}"
: "${JAVA_HOME:?Set JDK 17 or newer}"
: "${LIBXPOSED_API_JAR:?Set path to the libxposed API 102.0.0 classes.jar}"
: "${LIBXPOSED_INTERFACE_JAR:?Set path to the libxposed interface 102.0.0 classes.jar}"
: "${SONGYUAN_KEYSTORE:?Set path to your signing keystore}"
: "${SONGYUAN_KEY_PASSWORD_FILE:?Set path to your signing password file}"

sdk_tools="$ANDROID_SDK_ROOT/build-tools/${ANDROID_BUILD_TOOLS_VERSION:-36.0.0}"
android_jar="$ANDROID_SDK_ROOT/platforms/${ANDROID_PLATFORM_VERSION:-android-37.0}/android.jar"
javac="$JAVA_HOME/bin/javac"

mkdir -p build
work=$(mktemp -d "$PWD/build/staging.XXXXXX")
trap 'rm -rf -- "$work"' EXIT
mkdir -p "$work"/{classes,dex,tests}

"$javac" --release 8 -encoding UTF-8 \
    -cp "$android_jar:$LIBXPOSED_API_JAR:$LIBXPOSED_INTERFACE_JAR" \
    -d "$work/classes" src/main/java/dev/songyuan/hdr/*.java
"$javac" --release 8 -encoding UTF-8 -cp "$work/classes" \
    -d "$work/tests" tests/HdrPolicyTest.java
"$JAVA_HOME/bin/java" -ea -cp "$work/classes:$work/tests" dev.songyuan.hdr.HdrPolicyTest

"$JAVA_HOME/bin/jar" --create --file "$work/classes.jar" -C "$work/classes" .
"$JAVA_HOME/bin/java" -cp "$sdk_tools/lib/d8.jar" com.android.tools.r8.D8 \
    --min-api 33 --lib "$android_jar" --classpath "$LIBXPOSED_API_JAR" \
    --output "$work/dex" "$work/classes.jar" "$LIBXPOSED_INTERFACE_JAR"
"$sdk_tools/aapt2" compile --dir src/main/res -o "$work/resources.zip"
"$sdk_tools/aapt2" link -I "$android_jar" \
    --manifest src/main/AndroidManifest.xml -o "$work/base.apk" "$work/resources.zip"
(
    cd "$work/dex"
    zip -q -0 "$work/base.apk" classes.dex
)
(
    cd src/main/resources
    zip -q "$work/base.apk" META-INF/xposed/{module.prop,java_init.list,scope.list}
    zip -q "$work/base.apk" META-INF/licenses/libxposed-interface.txt
)
"$sdk_tools/zipalign" -f 4 "$work/base.apk" "$work/aligned.apk"
apk=build/K100ProMax_200MP_HDR_LSPosed_v0.1.5.apk
"$sdk_tools/apksigner" sign --ks "$SONGYUAN_KEYSTORE" --ks-key-alias songyuan-hdr \
    --ks-pass "file:$SONGYUAN_KEY_PASSWORD_FILE" --out "$apk" "$work/aligned.apk"
"$sdk_tools/apksigner" verify --verbose "$apk"
"$sdk_tools/zipalign" -c 4 "$apk"
