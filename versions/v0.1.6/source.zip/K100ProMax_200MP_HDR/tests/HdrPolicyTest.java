package dev.songyuan.hdr;

public final class HdrPolicyTest {
    public static void main(String[] args) {
        assert HdrPolicy.isSupportedDevice("songyuan");
        assert !HdrPolicy.isSupportedDevice("mivendor");
        assert !HdrPolicy.isSupportedDevice("unknown");
        assert !HdrPolicy.isSupportedDevice(null);
        assert HdrPolicy.is200Mp(16384, 12288);
        assert HdrPolicy.is200Mp(16320, 12288);
        assert HdrPolicy.is200Mp(12288, 16320);
        assert HdrPolicy.is200Mp(16320, 12240);
        assert !HdrPolicy.is200Mp(8160, 6144);
        assert !HdrPolicy.is200Mp(4096, 3072);
        assert HdrPolicy.supported(true, 0);
        assert HdrPolicy.supported(false, 1);
        assert !HdrPolicy.supported(false, 2);
        assert !HdrPolicy.supported(false, 4);
        assert HdrPolicy.activatesHdr("auto");
        assert HdrPolicy.activatesHdr("normal");
        assert HdrPolicy.activatesHdr("on");
        assert !HdrPolicy.activatesHdr("off");
        assert !HdrPolicy.activatesHdr(null);
        assert HdrPolicy.shouldForceHighResScene(true, "auto", false, false);
        assert HdrPolicy.shouldForceHighResScene(true, "on", false, false);
        assert HdrPolicy.shouldForceHighResScene(true, "normal", false, false);
        assert !HdrPolicy.shouldForceHighResScene(false, "auto", false, false);
        assert !HdrPolicy.shouldForceHighResScene(true, "off", false, false);
        assert !HdrPolicy.shouldForceHighResScene(true, "auto", true, false);
        assert !HdrPolicy.shouldForceHighResScene(true, "auto", false, true);
    }
}
