# v0.1.6 — 200MP Auto HDR scene trigger fix

## Root cause in v0.1.5

The previous implementation exposed the stock Auto HDR component and injected the component/request capability masks, but its `onHdrSceneChanged(boolean)` hook only observed the result after the stock callback. When the stock scene detector returned `false`, the stock state machine retained `xiaomi.hdr.enabled=false`. The module therefore reached `READY` and `component ready` without causing an HDR capture request.

## Change

- For the 200MP rear-camera path only, when the stock preference is `auto`, `on`, or `normal`, and the stock component is neither muted nor empty, pass `true` into the original `r6.b.onHdrSceneChanged(boolean)` callback when it would otherwise receive `false`.
- Before the stock HDR-preference application method runs, keep the internal scene state true under the same guard.
- Do not directly write `xiaomi.hdr.enabled`, `xiaomi.hdr.hdrMode`, checker tags, frame counts, or exposure values. The original Xiaomi state machine remains responsible for constructing the request and exposure strategy.
- Explicit `off`, muted, empty, non-200MP, non-rear, and unsupported paths retain stock behavior.
- Status UI distinguishes the module-forced scene state from an ordinary stock scene detection result.

## Validation completed here

- `HdrPolicyTest` compiled and passed using the local JDK.
- `HdrModule` and `HdrPolicy` passed a Java compile check against minimal API stubs, including the API 102 `Chain.proceedWith(thisObject, args)` call shape.
- This is a source-level repair only. It has not been built against the full Android 37 SDK/libxposed artifacts and has not been installed or verified on the phone. A successful app-layer request still does not prove that the HAL/provider executed multi-frame HDR fusion.

## Behavior / trade-off

With the stock preference set to Auto, 200MP shots will now be treated as HDR scenes rather than waiting for the original scene detector. This may increase capture time and can produce motion ghosting. Selecting Off remains the opt-out.
