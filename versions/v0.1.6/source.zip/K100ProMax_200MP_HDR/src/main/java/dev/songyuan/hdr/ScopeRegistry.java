package dev.songyuan.hdr;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

final class ScopeRegistry {
    private ScopeRegistry() {
    }

    static void read(SQLiteDatabase db, int user, String sourceApk, JSONObject report)
            throws JSONException {
        List<String> moduleColumns = columns(db, "modules");
        List<String> scopeColumns = columns(db, "scope");
        String pkg = find(moduleColumns, "module_pkg_name", "package_name", "pkg_name");
        String id = find(moduleColumns, "mid", "module_id", "id");
        String apk = find(moduleColumns, "apk_path", "module_apk_path", "source_dir");
        String enabled = find(moduleColumns, "enabled", "is_enabled");
        String targetModule = find(scopeColumns, "module_pkg_name", "mid", "module_id");
        String targetPackage = find(scopeColumns, "app_pkg_name", "package_name", "app_package_name");
        String targetUser = find(scopeColumns, "user_id", "userid");
        boolean packageLink = "module_pkg_name".equals(targetModule);

        if (pkg == null || (!packageLink && id == null) || targetModule == null || targetPackage == null
                || targetUser == null) {
            report.put("scope", "unavailable");
            report.put("scope_error", "框架数据库结构无法识别");
            reportSchema(db, report);
            return;
        }

        String query = "SELECT " + nullableColumn(id) + ", " + nullableColumn(apk) + ", "
                + nullableColumn(enabled) + " FROM modules WHERE " + quote(pkg) + " = ?";
        try (Cursor row = db.rawQuery(query, new String[] {HdrPolicy.MODULE})) {
            if (!row.moveToFirst()) {
                report.put("scope", "unregistered");
                return;
            }

            String moduleId = row.getString(0);
            String registeredApk = row.getString(1);
            String scopeKey = packageLink ? HdrPolicy.MODULE : moduleId;
            boolean selected = hasTarget(db, user, scopeKey, targetModule, targetPackage, targetUser);
            String switchState = enabledState(row.getString(2));

            if ("unknown".equals(switchState)) {
                switchState = readSeparateSwitch(db, moduleId, user);
            }
            report.put("scope_selected", selected);
            report.put("scope_switch", switchState);
            report.put("scope_apk", registeredApk == null || registeredApk.isEmpty() ? "unknown"
                    : sourceApk.equals(registeredApk) ? "match" : "different");

            if ("disabled".equals(switchState)) {
                report.put("scope", "disabled");
            } else if (!selected) {
                report.put("scope", "no_camera");
            } else {
                report.put("scope", "enabled".equals(switchState) ? "enabled" : "selected");
            }

            if ("unknown".equals(switchState)) {
                reportSchema(db, report);
            }
        }
    }

    private static boolean hasTarget(SQLiteDatabase db, int user, String moduleId,
                                     String module, String targetPackage, String targetUser) {
        String query = "SELECT 1 FROM scope WHERE " + quote(module) + " = ? AND "
                + quote(targetPackage) + " = ? AND " + quote(targetUser) + " = ? LIMIT 1";
        try (Cursor row = db.rawQuery(query,
                new String[] {moduleId, HdrPolicy.CAMERA, Integer.toString(user)})) {
            return row.moveToFirst();
        }
    }

    private static String readSeparateSwitch(SQLiteDatabase db, String moduleId, int user) {
        // Read explicit Boolean fields only. Unknown bit fields and missing rows have no meaning here.
        for (String table : new String[] {"modules_state", "module_state", "module_states", "module_enabled",
                "enabled_modules", "module_config", "module_configs"}) {
            List<String> names = columns(db, table);
            String id = find(names, "module_pkg_name", "mid", "module_id");
            String enabled = find(names, "enabled", "is_enabled");
            String stateKey = "module_pkg_name".equals(id) ? HdrPolicy.MODULE : moduleId;
            if (enabled == null || id == null || stateKey == null) {
                continue;
            }
            String userColumn = find(names, "user_id", "userid");
            String query = "SELECT " + quote(enabled) + " FROM " + quote(table)
                    + " WHERE " + quote(id) + " = ?";
            String[] args = {stateKey};
            if (userColumn != null) {
                query += " AND " + quote(userColumn) + " = ?";
                args = new String[] {stateKey, Integer.toString(user)};
            }
            try (Cursor row = db.rawQuery(query, args)) {
                if (row.moveToFirst() && row.getCount() == 1) {
                    String state = enabledState(row.getString(0));
                    if (!"unknown".equals(state)) {
                        return state;
                    }
                }
            }
        }
        return "unknown";
    }

    private static String enabledState(String value) {
        if ("1".equals(value) || "true".equalsIgnoreCase(value)) {
            return "enabled";
        }
        if ("0".equals(value) || "false".equalsIgnoreCase(value)) {
            return "disabled";
        }
        return "unknown";
    }

    private static List<String> columns(SQLiteDatabase db, String table) {
        List<String> result = new ArrayList<>();
        try (Cursor names = db.rawQuery("SELECT name FROM pragma_table_info(?) ORDER BY cid",
                new String[] {table})) {
            while (names.moveToNext() && result.size() < 40) {
                result.add(names.getString(0));
            }
        }
        return result;
    }

    private static String find(List<String> available, String... choices) {
        for (String name : choices) {
            if (available.contains(name)) {
                return name;
            }
        }
        return null;
    }

    private static String nullableColumn(String name) {
        return name == null ? "NULL" : quote(name);
    }

    private static String quote(String name) {
        return "\"" + name.replace("\"", "\"\"") + "\"";
    }

    static void reportSchema(SQLiteDatabase db, JSONObject report) throws JSONException {
        JSONObject schema = new JSONObject();
        try (Cursor tables = db.rawQuery(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                        + " ORDER BY name LIMIT 24", null)) {
            while (tables.moveToNext()) {
                String table = tables.getString(0);
                schema.put(table, new JSONArray(columns(db, table)));
            }
        }
        report.put("scope_schema", schema);
    }
}
