package dev.songyuan.hdr;

import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;
import android.util.Size;

import io.github.libxposed.api.XposedInterface.Chain;
import io.github.libxposed.api.XposedInterface.ExceptionMode;
import io.github.libxposed.api.XposedInterface.HookHandle;
import io.github.libxposed.api.XposedInterface.Hooker;
import io.github.libxposed.api.XposedModule;

import java.io.File;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import static dev.songyuan.hdr.HdrPolicy.CAMERA;
import static dev.songyuan.hdr.HdrPolicy.TAG;
import static dev.songyuan.hdr.HdrPolicy.VERSION;

public final class HdrModule extends XposedModule {
    private static final String HDR_MODE = "xiaomi.hdr.hdrMode";
    private static final String HDR_ENABLED = "xiaomi.hdr.enabled";
    private static final String HDR_CHECKER = "xiaomi.hdr.hdrChecker.enabled";
    private static final String STOCK_SIGNER =
            "c9009d01ebf9f5d0302bc71b2fe9aa9a47a432bba17308a3111b75d7b2149025";

    private final AtomicBoolean frameworkStartupInstalled = new AtomicBoolean();
    private final EnumSet<Startup> tried = EnumSet.noneOf(Startup.class);
    private final EnumSet<Startup> installedSources = EnumSet.noneOf(Startup.class);
    private final Set<Method> startupMethods = new HashSet<>();
    private final StatusJournal journal = new StatusJournal();
    private volatile String processName;
    private boolean finished;

    private enum Startup {
        CONTEXT_ATTACH, INSTRUMENTATION_CREATE, CAMERA_APPLICATION_CREATE,
        CAMERA_ACTIVITY_CREATE, CAMERA_ACTIVITY_RESUME, CURRENT_APPLICATION
    }

    @Override
    public void onModuleLoaded(ModuleLoadedParam param) {
        if (param.isSystemServer()) {
            return;
        }
        processName = param.getProcessName();
        if (!CAMERA.equals(processName)) {
            return;
        }
        int user = Process.myUid() / 100_000;
        journal.attach(new File("/data/user/" + user + "/" + CAMERA + "/cache"));
        noteEntry("module_entry", "MODULE_LOADED module=" + VERSION + " process=" + processName);
        installFrameworkStartup();
        tryCurrentApplication();
    }

    @Override
    public void onPackageLoaded(PackageLoadedParam param) {
        if (!matchesCameraPackage(param)) {
            return;
        }
        attachCameraCache(param.getApplicationInfo());
        noteEntry("package_loaded", "PACKAGE_LOADED module=" + VERSION);
        installFrameworkStartup();
        hookCameraApplication(param.getDefaultClassLoader());
    }

    @Override
    public void onPackageReady(PackageReadyParam param) {
        if (!matchesCameraPackage(param)) {
            return;
        }
        attachCameraCache(param.getApplicationInfo());
        noteEntry("package_ready", "ENTRY module=" + VERSION + " API=102 process=" + processName);
        installFrameworkStartup();
        ClassLoader loader = param.getClassLoader();
        hookCameraApplication(loader);
        hookBefore(Startup.CAMERA_ACTIVITY_CREATE, () ->
                method(loader.loadClass("com.android.camera.a"), "onCreate", Bundle.class),
                chain -> (Context) chain.getThisObject());
        hookBefore(Startup.CAMERA_ACTIVITY_RESUME, () ->
                method(loader.loadClass("com.android.camera.a"), "onResume"),
                chain -> (Context) chain.getThisObject());
        tryCurrentApplication();
    }

    private boolean matchesCameraPackage(PackageLoadedParam param) {
        if (!CAMERA.equals(param.getPackageName())) {
            return false;
        }
        String actual = processName == null ? Application.getProcessName() : processName;
        if (actual == null || actual.isEmpty()) {
            return param.isFirstPackage();
        }
        ApplicationInfo app = param.getApplicationInfo();
        return CAMERA.equals(actual) || (app != null && actual.equals(app.processName));
    }

    private void attachCameraCache(ApplicationInfo app) {
        if (app != null && app.dataDir != null && CAMERA.equals(app.packageName)
                && app.uid == Process.myUid()) {
            journal.attach(new File(app.dataDir, "cache"));
        }
    }

    private synchronized void noteEntry(String key, String message) {
        if (!finished && tried.isEmpty()) {
            journal.update("phase", "WAITING_CONTEXT");
        }
        report(key, message);
    }

    private void installFrameworkStartup() {
        if (!frameworkStartupInstalled.compareAndSet(false, true)) {
            return;
        }
        hookStartup(Startup.CONTEXT_ATTACH, () ->
                method(ContextWrapper.class, "attachBaseContext", Context.class), chain -> {
                    Object result = chain.proceed();
                    if (chain.getThisObject() instanceof Application) {
                        start((Application) chain.getThisObject(), Startup.CONTEXT_ATTACH);
                    }
                    return result;
                });
        hookBefore(Startup.INSTRUMENTATION_CREATE, () ->
                method(Instrumentation.class, "callApplicationOnCreate", Application.class),
                chain -> (Application) chain.getArg(0));
    }

    private void hookCameraApplication(ClassLoader loader) {
        if (loader != null) {
            hookBefore(Startup.CAMERA_APPLICATION_CREATE, () ->
                    method(loader.loadClass("com.android.camera.CameraAppImpl"), "onCreate"),
                    chain -> (Context) chain.getThisObject());
        }
    }

    private interface StartupMethod {
        Method resolve() throws ReflectiveOperationException;
    }

    private interface StartupContext {
        Context get(Chain chain);
    }

    private void hookBefore(Startup source, StartupMethod target, StartupContext context) {
        hookStartup(source, target, chain -> {
            start(context.get(chain), source);
            return chain.proceed();
        });
    }

    private synchronized void hookStartup(Startup source, StartupMethod target, Hooker hooker) {
        if (finished) {
            return;
        }
        try {
            Method member = target.resolve();
            if (!startupMethods.contains(member)) {
                intercept(member, hooker);
                startupMethods.add(member);
                installedSources.add(source);
                journal.update("startup_hooks", installedSources.toString());
            }
        } catch (Throwable error) {
            report("startup_hook_error", "BOOTSTRAP_HOOK_ERROR source=" + source + " " + describe(error));
        }
    }

    private void tryCurrentApplication() {
        try {
            Class<?> activityThread = Class.forName("android.app.ActivityThread");
            Context current = (Context) method(activityThread, "currentApplication").invoke(null);
            if (current != null) {
                start(current, Startup.CURRENT_APPLICATION);
            }
        } catch (ReflectiveOperationException | RuntimeException unavailable) {
            journal.update("current_application", describe(unavailable));
        }
    }

    private synchronized void start(Context context, Startup source) {
        if (finished || context == null || !CAMERA.equals(context.getPackageName())
                || !tried.add(source)) {
            return;
        }
        journal.attach(context);
        report("phase", "BOOTSTRAP source=" + source);
        try {
            if (!HdrPolicy.isSupportedDevice(Build.DEVICE)) {
                stop("device build=" + Build.DEVICE + " expected=songyuan");
                return;
            }
            if (Build.VERSION.SDK_INT != HdrPolicy.SDK_VERSION) {
                stop("android_sdk actual=" + Build.VERSION.SDK_INT
                        + " expected=" + HdrPolicy.SDK_VERSION);
                return;
            }
            PackageInfo camera = context.getPackageManager().getPackageInfo(
                    CAMERA, PackageManager.GET_SIGNING_CERTIFICATES);
            if (camera.getLongVersionCode() != HdrPolicy.CAMERA_VERSION_CODE
                    || !HdrPolicy.CAMERA_VERSION.equals(camera.versionName)) {
                stop("camera_version actual=" + camera.versionName
                        + " code=" + camera.getLongVersionCode());
                return;
            }
            if (!matchesStockSigner(camera)) {
                stop("camera_signer camera=" + camera.versionName);
                return;
            }
            CameraHooks hooks = new CameraHooks(context.getClassLoader());
            hooks.install();
            finished = true;
            report("phase", "READY device=" + Build.DEVICE + " camera=" + camera.versionName
                    + " sdk=" + Build.VERSION.SDK_INT + " source=" + source);
        } catch (Throwable error) {
            report("phase", "BOOTSTRAP_ERROR source=" + source + " " + describe(error));
        }
    }

    private void stop(String reason) {
        finished = true;
        report("phase", "STOP reason=" + reason);
    }

    private HookHandle intercept(Method method, Hooker hooker) {
        return hook(method).setExceptionMode(ExceptionMode.PROTECTIVE).intercept(hooker);
    }

    private static String describe(Throwable error) {
        Throwable cause = error.getCause();
        String message = error.getClass().getSimpleName() + " " + error.getMessage();
        if (cause != null) {
            message += " cause=" + cause.getClass().getSimpleName() + " " + cause.getMessage();
        }
        return message;
    }

    private static boolean matchesStockSigner(PackageInfo camera) throws Exception {
        if (camera.signingInfo == null) {
            return false;
        }
        Signature[] signers = camera.signingInfo.getApkContentsSigners();
        if (signers == null || signers.length != 1) {
            return false;
        }
        byte[] expected = new byte[32];
        for (int index = 0; index < expected.length; index++) {
            expected[index] = (byte) Integer.parseInt(
                    STOCK_SIGNER.substring(2 * index, 2 * index + 2), 16);
        }
        byte[] actual = MessageDigest.getInstance("SHA-256").digest(signers[0].toByteArray());
        return Arrays.equals(expected, actual);
    }

    private void info(String message) {
        Log.i(TAG, message);
        try {
            log(Log.INFO, TAG, message);
        } catch (RuntimeException ignored) {
            // The Android log remains available if the framework logger rejects the message.
        }
    }

    private void report(String field, String message) {
        journal.update(field, message);
        info(message);
    }

    private static Method method(Class<?> owner, String name, Class<?>... types)
            throws ReflectiveOperationException {
        Method resolved = owner.getDeclaredMethod(name, types);
        resolved.setAccessible(true);
        return resolved;
    }

    private static Field field(Class<?> owner, String name) throws ReflectiveOperationException {
        for (Class<?> type = owner; type != null; type = type.getSuperclass()) {
            try {
                Field resolved = type.getDeclaredField(name);
                resolved.setAccessible(true);
                return resolved;
            } catch (NoSuchFieldException ignored) {
                // The target can inherit fields from its camera base class.
            }
        }
        throw new NoSuchFieldException(owner.getName() + "." + name);
    }

    private final class CameraHooks {
        private final ThreadLocal<ScopedMask> mask = new ThreadLocal<>();
        private final Method readHdHdrBits;
        private final Method refreshHdr;
        private final Method defaultHdr;
        private final Method hdrValue;
        private final Method hdrMuted;
        private final Method hdrEmpty;
        private final Method buildRequest;
        private final Method cameraCapabilities;
        private final Method outputSizes;
        private final Method supportedTag;
        private final Method supportsHdr;
        private final Method selectedPixelSlot;
        private final Method selected200Legacy;
        private final Method runSettings;
        private final Method highResolutionStatus;
        private final Method customPixelProfile;
        private final Method applyHdrPreferences;
        private final Method onHdrSceneChanged;
        private final Method moduleMode;
        private final Method tagKey;
        private final Field refreshMode;
        private final Field refreshCapabilities;
        private final Field characteristics;
        private final Field cameraId;
        private final Field hasAuto;
        private final Field shootingPreferences;
        private final Field shootingValues;
        private final Field shootingMode;
        private final Field profileHolder;
        private final Field currentProfile;
        private final Field hdrOwner;
        private final Field hdrScene;
        private final Field hdrModeTag;
        private final Field hdrEnabledTag;
        private final Field hdrCheckerTag;
        private final Field hdrCheckerStatusTag;

        private volatile boolean enabled;
        private volatile Config config;
        private String lastRequest;
        private String lastBlocked;
        private Boolean lastScene;
        private long lastCaptureLog;

        CameraHooks(ClassLoader loader) throws ReflectiveOperationException {
            Class<?> capabilities = loader.loadClass("n9.d");
            Class<?> capabilityChecks = loader.loadClass("n9.e");
            Class<?> component = loader.loadClass("s2.z");
            Class<?> data = loader.loadClass("com.android.camera.data.data.F");
            Class<?> bridge = loader.loadClass("n9.A0");
            Class<?> tag = loader.loadClass("la.E0");
            Class<?> hdr = loader.loadClass("r6.b");
            Class<?> cameraModule = loader.loadClass("com.android.camera.module.r");
            Class<?> specialPixel = loader.loadClass("com.android.camera.data.data.p");
            Class<?> deviceFeatures = loader.loadClass("Te.c");

            readHdHdrBits = method(capabilities, "e0");
            refreshHdr = method(component, "w", data);
            defaultHdr = method(component, "getDefaultValue", int.class);
            hdrValue = method(component, "getComponentValue", int.class);
            hdrMuted = method(component, "u", int.class);
            hdrEmpty = method(loader.loadClass("com.android.camera.data.data.c"), "isEmpty");
            buildRequest = method(bridge, "E1", int.class, CaptureRequest.Builder.class);
            cameraCapabilities = method(bridge, "q");
            outputSizes = method(capabilities, "l0", int.class);
            supportedTag = method(capabilities, "S0", String.class);
            supportsHdr = method(capabilityChecks, "V2", capabilities);
            selectedPixelSlot = method(specialPixel, "D");
            selected200Legacy = method(specialPixel, "m0");
            runSettings = method(loader.loadClass("h2.a"), "j");
            highResolutionStatus = method(runSettings.getReturnType(), "F");
            profileHolder = field(loader.loadClass("Te.c$b"), "a");
            currentProfile = field(deviceFeatures, "e");
            customPixelProfile = method(currentProfile.getType(), "A5");
            applyHdrPreferences = method(hdr, "i");
            onHdrSceneChanged = method(hdr, "onHdrSceneChanged", boolean.class);
            moduleMode = method(cameraModule, "getModuleIndex");
            Class<?> vendorRequests = loader.loadClass("la.B0");
            hdrModeTag = field(vendorRequests, "t");
            hdrEnabledTag = field(vendorRequests, "m");
            hdrCheckerTag = field(vendorRequests, "p");
            hdrCheckerStatusTag = field(vendorRequests, "q");
            tagKey = method(tag, "a");

            refreshMode = field(data, "a");
            refreshCapabilities = field(data, "c");
            characteristics = field(capabilities, "d");
            cameraId = field(capabilities, "e");
            hasAuto = field(component, "b");
            shootingPreferences = field(bridge, "G");
            shootingValues = field(shootingPreferences.getType(), "a");
            shootingMode = field(shootingValues.getType(), "M3");
            hdrOwner = field(hdr, "a");
            hdrScene = field(hdr, "e");
        }

        void install() throws Throwable {
            List<HookHandle> installed = new ArrayList<>();
            try {
                installed.add(intercept(readHdHdrBits, chain -> {
                    Object result = chain.proceed();
                    ScopedMask current = mask.get();
                    if (enabled && current != null && current.capabilities == chain.getThisObject()) {
                        return (Integer) result | current.bits;
                    }
                    return result;
                }));
                installed.add(intercept(refreshHdr, chain -> {
                    Object component = chain.getThisObject();
                    Config scoped = prepareConfig(component, chain.getArg(0));
                    if (scoped == null) {
                        return chain.proceed();
                    }
                    Object result = proceedWithMask(chain, scoped.capabilities,
                            HdrPolicy.HD_HDR_COMPONENT);
                    finishConfig(component, scoped);
                    return result;
                }));
                installed.add(intercept(defaultHdr, chain -> {
                    Object result = chain.proceed();
                    return preferredHdr(chain.getThisObject(), (Integer) chain.getArg(0), result);
                }));
                installed.add(intercept(buildRequest, chain -> {
                    CaptureRequest.Builder request = (CaptureRequest.Builder) chain.getArg(1);
                    Object bridge = chain.getThisObject();
                    if (request == null || !is200Request(bridge)) {
                        return chain.proceed();
                    }
                    ScopedMask requestMask = prepareRequest(bridge);
                    Object result = requestMask == null ? chain.proceed()
                            : proceedWithMask(chain, requestMask.capabilities, requestMask.bits);
                    inspectRequest((Integer) chain.getArg(0), request);
                    return result;
                }));
                installed.add(intercept(applyHdrPreferences, chain -> {
                    Object hdr = chain.getThisObject();
                    if (shouldForceHighResScene(hdr)) {
                        // Keep the stock preference-to-request path intact; only
                        // supply the scene state it requires for 200MP Auto HDR.
                        hdrScene.setBoolean(hdr, true);
                        journal.update("scene_source", "MODULE_FORCED_200MP_AUTO_HDR");
                    }
                    Object result = chain.proceed();
                    inspectPreference(hdr);
                    return result;
                }));
                installed.add(intercept(onHdrSceneChanged, chain -> {
                    Object hdr = chain.getThisObject();
                    boolean incoming = Boolean.TRUE.equals(chain.getArg(0));
                    Object result;
                    if (!incoming && shouldForceHighResScene(hdr)) {
                        // The v0.1.5 hook only observed a false scene result.
                        // Pass true into Xiaomi's original callback so its own
                        // state machine builds the HDR request and exposure plan.
                        journal.update("scene_source", "MODULE_FORCED_200MP_AUTO_HDR");
                        result = chain.proceedWith(hdr, new Object[] {Boolean.TRUE});
                    } else {
                        result = chain.proceed();
                    }
                    inspectScene(hdr);
                    return result;
                }));

                // Recompile the two callers without inlining the capability getter.
                deoptimize(refreshHdr);
                deoptimize(buildRequest);
                enabled = true;
            } catch (Throwable error) {
                for (HookHandle handle : installed) {
                    try {
                        handle.unhook();
                    } catch (RuntimeException rollbackError) {
                        error.addSuppressed(rollbackError);
                    }
                }
                throw error;
            }
        }

        private Object proceedWithMask(Chain chain, Object capabilities, int bits) throws Throwable {
            ScopedMask previous = mask.get();
            mask.set(new ScopedMask(capabilities, bits));
            try {
                return chain.proceed();
            } finally {
                if (previous == null) {
                    mask.remove();
                } else {
                    mask.set(previous);
                }
            }
        }

        private Config prepareConfig(Object component, Object data) {
            if (!enabled) {
                return null;
            }
            try {
                int mode = refreshMode.getInt(data);
                if (mode != HdrPolicy.HIGH_RES_MODE) {
                    return null;
                }
                Config previous = config;
                if (previous != null && previous.component.get() == component) {
                    config = null;
                }
                boolean customProfile = customPixelProfile();
                if (!is200Selected(customProfile)) {
                    return null;
                }
                Object caps = refreshCapabilities.get(data);
                if (!eligible(caps)) {
                    return null;
                }
                int nativeBits = (Integer) readHdHdrBits.invoke(caps);
                if (!HdrPolicy.supported(customProfile, nativeBits)) {
                    blocked("native high-resolution HDR route missing, hdhdr=" + nativeBits);
                    return null;
                }
                return new Config(component, caps, cameraId.getInt(caps), nativeBits, customProfile);
            } catch (Exception error) {
                fail(error);
                return null;
            }
        }

        private void finishConfig(Object component, Config scoped) {
            if (!enabled) {
                return;
            }
            try {
                if (!hasAuto.getBoolean(component)) {
                    blocked("stock component did not offer HDR Auto");
                    return;
                }
                config = scoped;
                synchronized (this) {
                    lastRequest = null;
                    lastScene = null;
                    lastBlocked = null;
                }
                report("mode", "200MP component ready, cameraId=" + scoped.cameraId
                        + " stockHdhdr=0x" + Integer.toHexString(scoped.nativeBits)
                        + " requestRoute=" + scoped.customProfile);
            } catch (Exception error) {
                fail(error);
            }
        }

        private boolean eligible(Object caps) throws ReflectiveOperationException {
            if (caps == null) {
                blocked("camera characteristics unavailable");
                return false;
            }
            CameraCharacteristics values = (CameraCharacteristics) characteristics.get(caps);
            if (!Integer.valueOf(CameraCharacteristics.LENS_FACING_BACK)
                    .equals(values.get(CameraCharacteristics.LENS_FACING))) {
                blocked("200MP rear camera not identified");
                return false;
            }
            boolean fullSize = false;
            for (Object item : (List<?>) outputSizes.invoke(caps, 33)) {
                Size size = (Size) item;
                if (HdrPolicy.is200Mp(size.getWidth(), size.getHeight())) {
                    fullSize = true;
                    break;
                }
            }
            if (!fullSize) {
                blocked("camera exposes no 200MP JPEG output");
                return false;
            }
            if (!Boolean.TRUE.equals(supportsHdr.invoke(null, caps))) {
                blocked("stock camera reports HDR unsupported");
                return false;
            }
            for (String name : new String[] {HDR_ENABLED, HDR_CHECKER, HDR_MODE}) {
                if (!Boolean.TRUE.equals(supportedTag.invoke(caps, name))) {
                    blocked("camera tag unavailable: " + name);
                    return false;
                }
            }
            return true;
        }

        private Object preferredHdr(Object component, int mode, Object original) {
            Config state = config;
            if (!enabled || state == null || mode != HdrPolicy.HIGH_RES_MODE
                    || state.component.get() != component) {
                return original;
            }
            try {
                if (is200Selected(state.customProfile)
                        && !Boolean.TRUE.equals(hdrMuted.invoke(component, HdrPolicy.HIGH_RES_MODE))
                        && !Boolean.TRUE.equals(hdrEmpty.invoke(component))) {
                    return "auto";
                }
            } catch (Exception error) {
                fail(error);
            }
            return original;
        }

        private boolean customPixelProfile() throws ReflectiveOperationException {
            Object device = profileHolder.get(null);
            return Boolean.TRUE.equals(customPixelProfile.invoke(currentProfile.get(device)));
        }

        private boolean is200Selected(boolean customProfile) throws ReflectiveOperationException {
            if (customProfile) {
                return Boolean.TRUE.equals(selectedPixelSlot.invoke(null))
                        && Boolean.TRUE.equals(selected200Legacy.invoke(null));
            }
            Object running = runSettings.invoke(null);
            return Boolean.TRUE.equals(highResolutionStatus.invoke(running));
        }

        private boolean is200Request(Object bridge) {
            if (!enabled) {
                return false;
            }
            try {
                Object preferences = shootingPreferences.get(bridge);
                Object values = preferences == null ? null : shootingValues.get(preferences);
                return values != null && shootingMode.getInt(values) == HdrPolicy.HIGH_RES_MODE
                        && is200Selected(customPixelProfile());
            } catch (Exception error) {
                fail(error);
                return false;
            }
        }

        private ScopedMask prepareRequest(Object bridge) {
            Config state = config;
            if (!enabled || state == null) {
                return null;
            }
            Object component = state.component.get();
            if (component == null) {
                return null;
            }
            try {
                Object caps = cameraCapabilities.invoke(bridge);
                if (caps == null || cameraId.getInt(caps) != state.cameraId
                        || !Boolean.TRUE.equals(supportedTag.invoke(caps, HDR_MODE))) {
                    return null;
                }
                String preference = (String) hdrValue.invoke(component, HdrPolicy.HIGH_RES_MODE);
                if (!HdrPolicy.activatesHdr(preference)) {
                    blocked("camera HDR preference=" + preference);
                    return null;
                }
                return new ScopedMask(caps, state.customProfile ? HdrPolicy.HD_HDR_REQUEST : 0);
            } catch (Exception error) {
                fail(error);
                return null;
            }
        }

        private void inspectRequest(int stage, CaptureRequest.Builder request) {
            if (!enabled) {
                return;
            }
            try {
                Object route = requestValue(request, hdrModeTag);
                Object hdr = requestValue(request, hdrEnabledTag);
                Object checker = requestValue(request, hdrCheckerTag);
                Object checkerStatus = requestValue(request, hdrCheckerStatusTag);
                String status = "request stage=" + stage + " hdrMode=" + route
                        + " hdrEnabled=" + hdr + " checker=" + checker
                        + " checkerStatus=" + checkerStatus;
                synchronized (this) {
                    if (stage == 3) {
                        long now = SystemClock.elapsedRealtime();
                        if (now - lastCaptureLog > 250) {
                            lastCaptureLog = now;
                            report("capture", status);
                        }
                    } else if (!status.equals(lastRequest)) {
                        lastRequest = status;
                        journal.update("request", status);
                        Log.i(TAG, status);
                    }
                }
            } catch (Exception error) {
                Log.d(TAG, "request readback unavailable", error);
            }
        }

        private Object requestValue(CaptureRequest.Builder builder, Field vendorField) {
            try {
                Object vendorTag = vendorField.get(null);
                Object key = tagKey.invoke(vendorTag);
                return builder.get((CaptureRequest.Key<?>) key);
            } catch (Exception unavailable) {
                return null;
            }
        }

        private boolean shouldForceHighResScene(Object hdr)
                throws ReflectiveOperationException {
            Config state = config;
            if (!enabled || state == null || state.component.get() == null
                    || !activeHighResOwner(hdr)) {
                return false;
            }
            Object component = state.component.get();
            String preference = (String) hdrValue.invoke(component, HdrPolicy.HIGH_RES_MODE);
            boolean muted = Boolean.TRUE.equals(
                    hdrMuted.invoke(component, HdrPolicy.HIGH_RES_MODE));
            boolean empty = Boolean.TRUE.equals(hdrEmpty.invoke(component));
            return HdrPolicy.shouldForceHighResScene(true, preference, muted, empty);
        }

        private void inspectPreference(Object hdr) {
            try {
                if (!enabled || !activeHighResOwner(hdr)) {
                    return;
                }
                Config state = config;
                if (state == null) {
                    blocked("200MP HDR preference was not initialized by the stock component");
                }
            } catch (Exception error) {
                Log.d(TAG, "preference diagnostics unavailable", error);
            }
        }

        private void inspectScene(Object hdr) {
            Config state = config;
            if (!enabled || state == null) {
                return;
            }
            try {
                if (!activeHighResOwner(hdr)) {
                    return;
                }
                boolean detected = hdrScene.getBoolean(hdr);
                synchronized (this) {
                    if (lastScene == null || lastScene != detected) {
                        lastScene = detected;
                        journal.update("scene", Boolean.toString(detected));
                        info("stock HDR scene accepted=" + detected);
                    }
                }
            } catch (Exception error) {
                Log.d(TAG, "scene diagnostics unavailable", error);
            }
        }

        private boolean activeHighResOwner(Object hdr) throws ReflectiveOperationException {
            Object owner = ((WeakReference<?>) hdrOwner.get(hdr)).get();
            return owner != null && (Integer) moduleMode.invoke(owner) == HdrPolicy.HIGH_RES_MODE
                    && is200Selected(customPixelProfile());
        }

        private synchronized void blocked(String reason) {
            if (!reason.equals(lastBlocked)) {
                lastBlocked = reason;
                report("mode", "200MP stock route retained: " + reason);
            }
        }

        private synchronized void fail(Exception error) {
            if (enabled) {
                enabled = false;
                config = null;
                report("phase", "STOP hook error: " + describe(error));
            }
        }

    }

    private static final class Config {
        final WeakReference<Object> component;
        final Object capabilities;
        final int cameraId;
        final int nativeBits;
        final boolean customProfile;

        Config(Object component, Object capabilities, int cameraId, int nativeBits, boolean customProfile) {
            this.component = new WeakReference<>(component);
            this.capabilities = capabilities;
            this.cameraId = cameraId;
            this.nativeBits = nativeBits;
            this.customProfile = customProfile;
        }
    }

    private static final class ScopedMask {
        final Object capabilities;
        final int bits;

        ScopedMask(Object capabilities, int bits) {
            this.capabilities = capabilities;
            this.bits = bits;
        }
    }
}
