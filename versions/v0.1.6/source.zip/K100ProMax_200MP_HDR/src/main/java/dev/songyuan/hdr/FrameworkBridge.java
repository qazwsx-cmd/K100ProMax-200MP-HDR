package dev.songyuan.hdr;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;

import io.github.libxposed.service.HookedProcess;
import io.github.libxposed.service.IXposedService;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/** Accepts the framework service Binder through the libxposed provider contract. */
public final class FrameworkBridge extends ContentProvider {
    private static volatile IXposedService service;

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        int caller = Binder.getCallingUid();
        if ((caller != 0 && caller != 1000) || !IXposedService.SEND_BINDER.equals(method)
                || extras == null) {
            return null;
        }
        IBinder binder = extras.getBinder("binder");
        if (binder == null) {
            return null;
        }
        try {
            if (!IXposedService.DESCRIPTOR.equals(binder.getInterfaceDescriptor())) {
                return null;
            }
            connect(binder);
            return new Bundle();
        } catch (RemoteException unavailable) {
            return null;
        }
    }

    private static synchronized void connect(IBinder binder) throws RemoteException {
        IXposedService previous = service;
        if (previous != null && previous.asBinder() == binder) {
            return;
        }
        IXposedService current = IXposedService.Stub.asInterface(binder);
        binder.linkToDeath(() -> disconnect(current), 0);
        service = current;
    }

    private static synchronized void disconnect(IXposedService previous) {
        if (service == previous) {
            service = null;
        }
    }

    static void readStatus(int user, JSONObject report) throws JSONException {
        IXposedService connection = service;
        if (connection == null) {
            report.put("framework_service", "not_connected");
            return;
        }
        report.put("framework_service", "connected");
        int api = 0;
        try {
            api = connection.getApiVersion();
            report.put("framework_api", api);
            report.put("framework_service_name", connection.getFrameworkName());
            report.put("framework_service_version", connection.getFrameworkVersion());
        } catch (RemoteException | RuntimeException error) {
            report.put("framework_service_error", describe(error));
        }

        try {
            List<String> scope = connection.getScope();
            if (scope != null) {
                report.put("service_scope_camera", scope.contains(HdrPolicy.CAMERA));
            }
        } catch (RemoteException | RuntimeException error) {
            report.put("service_scope_error", describe(error));
        }
        if (api < IXposedService.API_102) {
            return;
        }

        try {
            List<HookedProcess> targets = connection.getRunningTargets();
            if (targets == null) {
                return;
            }
            JSONArray cameraTargets = new JSONArray();
            for (HookedProcess target : targets) {
                if (target != null && HdrPolicy.CAMERA.equals(target.processName)
                        && target.uid / 100_000 == user) {
                    JSONObject info = new JSONObject();
                    info.put("pid", target.pid);
                    info.put("state", stateName(target.state));
                    info.put("loaded_version_code", target.loadedVersionCode);
                    cameraTargets.put(info);
                }
            }
            report.put("framework_camera_targets", cameraTargets);
        } catch (RemoteException | RuntimeException error) {
            report.put("framework_targets_error", describe(error));
        }
    }

    private static String describe(Exception error) {
        return error.getClass().getSimpleName() + " " + error.getMessage();
    }

    private static String stateName(int state) {
        switch (state) {
            case HookedProcess.TARGET_STATE_UP_TO_DATE:
                return "up_to_date";
            case HookedProcess.TARGET_STATE_STALE:
                return "stale";
            case HookedProcess.TARGET_STATE_RELOADING:
                return "reloading";
            case HookedProcess.TARGET_STATE_FAILED:
                return "failed";
            default:
                return "unknown";
        }
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int delete(Uri uri, String selection, String[] args) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] args) {
        throw new UnsupportedOperationException();
    }
}
