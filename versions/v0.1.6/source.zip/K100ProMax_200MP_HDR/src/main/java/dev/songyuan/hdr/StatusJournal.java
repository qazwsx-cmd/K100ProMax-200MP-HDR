package dev.songyuan.hdr;

import android.content.Context;
import android.os.Process;
import android.util.AtomicFile;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

final class StatusJournal {
    private final Properties fields = new Properties();
    private final ThreadPoolExecutor writer = new ThreadPoolExecutor(0, 1, 5,
            TimeUnit.SECONDS, new LinkedBlockingQueue<>(), task -> {
                Thread thread = new Thread(task, "SongyuanHdrStatus");
                thread.setDaemon(true);
                return thread;
            });
    private AtomicFile file;
    private boolean pending;

    synchronized void attach(Context context) {
        if (file != null) {
            return;
        }
        try {
            attach(context.getCacheDir());
        } catch (RuntimeException error) {
            Log.w(HdrPolicy.TAG, "Status cache unavailable", error);
        }
    }

    synchronized void attach(File cache) {
        if (file != null || cache == null || !cache.isDirectory()) {
            return;
        }
        fields.setProperty("version", HdrPolicy.VERSION);
        fields.setProperty("pid", Integer.toString(Process.myPid()));
        fields.setProperty("start_ticks", processStartTicks("/proc/self/stat"));
        file = new AtomicFile(new File(cache, HdrPolicy.STATUS_FILE));
        scheduleWrite();
    }

    synchronized void update(String key, String value) {
        String now = Long.toString(System.currentTimeMillis());
        fields.setProperty(key, value);
        fields.setProperty("updated", now);
        if ("capture".equals(key)) {
            fields.setProperty("capture_at", now);
        }
        scheduleWrite();
    }

    private void scheduleWrite() {
        if (file != null && !pending) {
            pending = true;
            writer.execute(this::write);
        }
    }

    private void write() {
        Properties snapshot = new Properties();
        synchronized (this) {
            pending = false;
            snapshot.putAll(fields);
        }
        FileOutputStream stream = null;
        try {
            stream = file.startWrite();
            snapshot.store(stream, null);
            file.finishWrite(stream);
        } catch (IOException | RuntimeException error) {
            if (stream != null) {
                file.failWrite(stream);
            }
            Log.w(HdrPolicy.TAG, "Status write failed", error);
        }
    }

    static String processStartTicks(String statPath) {
        try (BufferedReader in = new BufferedReader(new FileReader(statPath))) {
            String line = in.readLine();
            if (line != null) {
                int endName = line.lastIndexOf(')');
                if (endName >= 0 && endName + 1 < line.length()) {
                    String[] fields = line.substring(endName + 1).trim().split("\\s+");
                    // The first field after the process name is field 3. Start time is field 22.
                    if (fields.length > 19) {
                        return fields[19];
                    }
                }
            }
        } catch (IOException | RuntimeException ignored) {
            // The pid still provides a useful match when procfs hides the start time.
        }
        return "";
    }
}
