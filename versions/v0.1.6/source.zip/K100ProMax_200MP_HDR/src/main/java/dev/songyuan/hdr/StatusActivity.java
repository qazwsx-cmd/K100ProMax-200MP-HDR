package dev.songyuan.hdr;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

public final class StatusActivity extends Activity {
    private static final int BACKGROUND = 0xff111a1f;
    private static final int CARD = 0xff1a282e;
    private static final int BORDER = 0xff30464e;
    private static final int TEXT = 0xffedf5f4;
    private static final int MUTED = 0xffa9bec0;
    private static final int GOOD = 0xff87edbc;
    private static final int ATTENTION = 0xffffd08c;
    private static final int ERROR = 0xffffaba5;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView summary;
    private Button refreshButton;
    private Button copyButton;
    private StatusCard scopeCard;
    private StatusCard processCard;
    private StatusCard hdrCard;
    private StatusCard captureCard;
    private boolean checking;
    private boolean rootAvailable;
    private String deviceSummary;
    private String diagnostics;

    @Override
    protected void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        deviceSummary = deviceSummary();
        createPage();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (rootAvailable) {
            refresh();
        }
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    private void createPage() {
        getWindow().setDecorFitsSystemWindows(false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(BACKGROUND);
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            android.graphics.Insets safe = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
            return WindowInsets.CONSUMED;
        });

        LinearLayout page = column();
        page.setPadding(dp(20), dp(24), dp(20), dp(24));
        scroll.addView(page, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        add(page, text("200MP HDR", 31, TEXT, true), 0);
        add(page, text(deviceSummary, 14, MUTED, false), 6);
        summary = text("点检查状态并允许 Root，读取 LSPosed 和系统相机的运行状态。", 14,
                MUTED, false);
        summary.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        add(page, summary, 12);

        refreshButton = button("检查状态", true);
        refreshButton.setOnClickListener(view -> refresh());
        add(page, refreshButton, 16);
        Button cameraButton = button("打开系统相机", false);
        cameraButton.setOnClickListener(view -> openCamera());
        add(page, cameraButton, 8);

        scopeCard = new StatusCard("LSPosed 作用域", "待检查", null);
        processCard = new StatusCard("相机进程", "待检查", null);
        hdrCard = new StatusCard("2 亿像素 HDR", "等待 200MP 模式", null);
        captureCard = new StatusCard("最近一次 200MP 快门请求", "尚未读取到拍摄请求", null);
        add(page, scopeCard.layout, 18);
        add(page, processCard.layout, 10);
        add(page, hdrCard.layout, 10);
        add(page, captureCard.layout, 10);

        copyButton = button("复制诊断", false);
        copyButton.setEnabled(false);
        copyButton.setOnClickListener(view -> copyReport());
        add(page, copyButton, 14);

        setContentView(scroll);
        scroll.requestApplyInsets();
    }

    private String deviceSummary() {
        String cameraVersion;
        try {
            PackageInfo camera = getPackageManager().getPackageInfo(HdrPolicy.CAMERA, 0);
            cameraVersion = camera.versionName;
        } catch (PackageManager.NameNotFoundException unavailable) {
            cameraVersion = "未找到";
        }
        return "K100 Pro Max · 模块 v" + HdrPolicy.VERSION + "\n设备 " + Build.DEVICE
                + " · 相机 " + cameraVersion;
    }

    private void refresh() {
        if (checking) {
            return;
        }
        checking = true;
        refreshButton.setEnabled(false);
        refreshButton.setText("检查中…");
        summary.setText("正在读取作用域、相机进程和最近的 HDR 状态。");
        worker.submit(() -> {
            try {
                JSONObject result = readReport();
                runOnUiThread(() -> {
                    if (!isDestroyed()) {
                        showReport(result);
                    }
                });
            } catch (Exception error) {
                String message = error.getMessage() == null
                        ? error.getClass().getSimpleName() : error.getMessage();
                runOnUiThread(() -> {
                    if (!isDestroyed()) {
                        showFailure(message);
                    }
                });
            }
        });
    }

    private JSONObject readReport() throws Exception {
        int user = getApplicationInfo().uid / 100_000;
        JSONObject result;
        try {
            result = readRootReport();
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw interrupted;
        } catch (Exception error) {
            result = new JSONObject();
            result.put("user", user);
            result.put("root_error", error.getMessage());
        }
        FrameworkBridge.readStatus(user, result);
        if (result.optInt("uid", -1) != 0 && result.optInt("framework_api") == 0) {
            throw new IOException(result.optString("root_error", "状态读取失败"));
        }
        return result;
    }

    private JSONObject readRootReport() throws Exception {
        String apk = getApplicationInfo().sourceDir;
        int user = getApplicationInfo().uid / 100_000;
        String command = "export CLASSPATH=" + shellQuote(apk)
                + "; exec /system/bin/app_process /system/bin "
                + ScopeDoctor.class.getName() + " " + user + " " + shellQuote(apk);
        java.lang.Process root = new ProcessBuilder("su", "-c", command)
                .redirectErrorStream(true).start();
        FutureTask<String> output = new FutureTask<>(() -> {
            StringBuilder all = new StringBuilder();
            try (BufferedReader lines = new BufferedReader(new InputStreamReader(
                    root.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = lines.readLine()) != null) {
                    if (all.length() < 64_000) {
                        all.append(line).append('\n');
                    }
                }
            }
            return all.toString();
        });
        Thread reader = new Thread(output, "SongyuanHdrProbeOutput");
        reader.setDaemon(true);
        reader.start();

        try {
            if (!root.waitFor(25, TimeUnit.SECONDS)) {
                throw new IOException("读取超时，请确认 KernelSU 授权。");
            }
            String raw = output.get(2, TimeUnit.SECONDS);
            for (String line : raw.split("\n")) {
                if (line.startsWith(ScopeDoctor.OUTPUT_PREFIX)) {
                    JSONObject result = new JSONObject(line.substring(ScopeDoctor.OUTPUT_PREFIX.length()));
                    if (result.optInt("uid", -1) == 0) {
                        return result;
                    }
                    break;
                }
            }
            String detail = raw.trim();
            if (detail.length() > 480) {
                detail = detail.substring(0, 480);
            }
            throw new IOException("诊断进程退出码 " + root.exitValue()
                    + (detail.isEmpty() ? "" : "\n" + detail));
        } finally {
            root.destroyForcibly();
            output.cancel(true);
        }
    }

    private static String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private void showReport(JSONObject result) {
        rootAvailable = result.optInt("uid", -1) == 0;
        finishRefresh();
        String checked = "上次检查 " + clock(System.currentTimeMillis());
        summary.setText(rootAvailable ? checked : checked + "\n已读取框架服务。允许 Root 可核对相机进程日志与状态。");
        diagnostics = deviceSummary() + "\n" + result.toString();
        copyButton.setEnabled(true);

        showScope(result);
        JSONObject record = result.optJSONObject("camera_record");
        boolean knownVersion = record != null && HdrPolicy.VERSION.equals(record.optString("version"));
        boolean current = knownVersion && result.optBoolean("camera_record_current");
        int pid = result.optInt("camera_pid");
        JSONArray targets = result.optJSONArray("framework_camera_targets");
        JSONObject target = matchingTarget(targets, pid);
        String phase = current ? record.optString("phase") : "";
        boolean ready = phase.startsWith("READY ");
        if (ready) {
            processCard.show("模块已初始化", "当前相机进程 " + pid + "\n" + phase, GOOD);
        } else if (current) {
            String label = "初始化未完成";
            if ("WAITING_CONTEXT".equals(phase) || phase.isEmpty()) {
                label = "已收到相机模块回调";
                phase = "等待相机应用上下文。";
            } else if (phase.startsWith("BOOTSTRAP ")) {
                label = "正在初始化";
            }
            String entry = record.optString("startup_hooks");
            String error = record.optString("startup_hook_error");
            String detail = "当前相机进程 " + pid + "\n" + phase;
            if (!entry.isEmpty()) {
                detail += "\n已注册 " + entry;
            }
            if (!error.isEmpty()) {
                detail += "\n" + error;
            }
            processCard.show(label, detail, ATTENTION);
        } else if (target != null) {
            showFrameworkTarget(target);
        } else if (pid == 0) {
            if (rootAvailable) {
                processCard.show("系统相机未运行", "打开系统相机，再返回此页检查。", MUTED);
            } else {
                processCard.show("等待相机进程状态", "Root 状态读取未完成。", MUTED);
            }
        } else {
            String bridge = "visible".equals(result.optString("camera_bridge"))
                    ? "已看到 LSPosed 框架映射。" : "";
            String hint = result.optBoolean("camera_hook_error")
                    ? "框架记录了启动 hook 错误，点复制诊断查看。" : "";
            String state = "尚未确认模块已初始化";
            if (result.optBoolean("camera_entry")) {
                state = "已进入相机模块入口，等待初始化";
            } else if (result.optBoolean("camera_module_loaded")) {
                state = "框架已加载模块，等待相机入口";
            } else if (targets != null) {
                state = "框架暂未报告此进程加载模块";
            }
            processCard.show(state, ("相机进程 " + pid + "。" + bridge + " " + hint).trim(),
                    ATTENTION);
        }
        showHdr(current ? record : null, ready);
        showCapture(knownVersion ? record : null, current);
    }

    private JSONObject matchingTarget(JSONArray targets, int pid) {
        if (targets == null) {
            return null;
        }
        for (int index = 0; index < targets.length(); index++) {
            JSONObject target = targets.optJSONObject(index);
            if (target != null && ((!rootAvailable && pid == 0) || target.optInt("pid") == pid)) {
                return target;
            }
        }
        return null;
    }

    private void showFrameworkTarget(JSONObject target) {
        int pid = target.optInt("pid");
        long loadedVersion = target.optLong("loaded_version_code");
        String label = "相机进程 " + pid;
        switch (target.optString("state")) {
            case "failed":
                processCard.show("框架报告模块加载失败", label, ERROR);
                break;
            case "stale":
                processCard.show("相机进程仍在使用旧版模块", label + " · 版本代码 " + loadedVersion,
                        ATTENTION);
                break;
            case "reloading":
                processCard.show("框架正在更新运行中的模块", label, ATTENTION);
                break;
            case "up_to_date":
                if (loadedVersion != HdrPolicy.VERSION_CODE) {
                    processCard.show("框架已登记相机进程", label + " · 版本代码 " + loadedVersion,
                            ATTENTION);
                } else {
                    processCard.show("框架已加载新版模块", label + " · 等待初始化记录", ATTENTION);
                }
                break;
            default:
                processCard.show("框架已登记相机进程", label, ATTENTION);
        }
    }

    private void showScope(JSONObject result) {
        String scope = result.optString("scope");
        String framework = result.optString("framework_version",
                result.optString("framework_service_version"));
        String version = framework.isEmpty() ? "" : "LSPosed " + framework + "\n";
        String user = "用户 " + result.optInt("user");
        switch (scope) {
            case "enabled":
                boolean stale = "different".equals(result.optString("scope_apk"));
                scopeCard.show("系统相机已勾选 · " + user, version
                        + (stale ? "框架记录的 APK 路径与已安装路径不同。" : "作用域记录已读取。"),
                        stale ? ATTENTION : GOOD);
                break;
            case "selected":
                String detail = "已读取此用户的相机作用域，模块开关状态待核对。";
                if ("different".equals(result.optString("scope_apk"))) {
                    detail += "\n框架记录的 APK 路径与已安装路径不同。";
                }
                scopeCard.show("系统相机在作用域内 · " + user, version + detail, ATTENTION);
                break;
            case "disabled":
                scopeCard.show("模块开关关闭", version + "在 LSPosed 管理器启用本模块。", ATTENTION);
                break;
            case "no_camera":
                scopeCard.show("当前用户的相机未勾选", version + user, ATTENTION);
                break;
            case "unregistered":
                scopeCard.show("框架尚未登记本模块", version + "在 LSPosed 管理器确认新版模块已显示。",
                        ATTENTION);
                break;
            default:
                if (result.has("service_scope_camera")) {
                    scopeCard.show(result.optBoolean("service_scope_camera")
                                    ? "框架服务返回相机在作用域内" : "框架服务的作用域里没有相机",
                            version + "此状态由框架服务返回。", ATTENTION);
                } else {
                    scopeCard.show("暂时无法读取作用域", version + result.optString("scope_error"),
                            ATTENTION);
                }
        }
    }

    private void showHdr(JSONObject record, boolean ready) {
        if (record == null || !ready) {
            hdrCard.show("等待相机模块初始化", null, MUTED);
            return;
        }
        String mode = record.optString("mode");
        String scene = record.optString("scene");
        String sceneSource = record.optString("scene_source");
        String sceneLabel;
        if ("MODULE_FORCED_200MP_AUTO_HDR".equals(sceneSource)) {
            sceneLabel = "模块已将 HDR 场景交给原厂状态机";
        } else if ("true".equals(scene)) {
            sceneLabel = "最近检测到 HDR 场景";
        } else if ("false".equals(scene)) {
            sceneLabel = "最近一次判定未触发 HDR";
        } else {
            sceneLabel = "等待原厂场景判定";
        }
        if (mode.startsWith("200MP component ready")) {
            hdrCard.show("原厂 Auto HDR 组件已就绪", sceneLabel, GOOD);
        } else if (!mode.isEmpty()) {
            hdrCard.show("当前沿用原厂高像素流程", mode, ATTENTION);
        } else {
            hdrCard.show("等待进入超清 200MP", "在系统相机切到超清里的 200MP。", MUTED);
        }
    }

    private void showCapture(JSONObject record, boolean current) {
        String capture = record == null ? "" : record.optString("capture");
        if (capture.isEmpty()) {
            captureCard.show("尚未读取到拍摄请求", null, MUTED);
            return;
        }
        String when = clock(record.optLong("capture_at"));
        String detail = (current ? "" : "上次相机进程\n")
                + (when.isEmpty() ? "" : when + "\n") + capture;
        if (capture.contains(" hdrEnabled=true ")) {
            captureCard.show("快门请求带 HDR", detail + "\n成片融合需核对原图。", GOOD);
        } else if (capture.contains(" hdrEnabled=false ")) {
            captureCard.show("快门请求未启用 HDR", detail, ATTENTION);
        } else {
            captureCard.show("快门请求的 HDR 值未知", detail, ATTENTION);
        }
    }

    private void showFailure(String error) {
        rootAvailable = false;
        finishRefresh();
        summary.setText("无法运行 Root 状态检查。请在 KernelSU 管理器允许「K100 Pro Max 200MP HDR」，再点检查。");
        scopeCard.show("状态读取失败", error, ERROR);
        processCard.show("待检查", null, MUTED);
        hdrCard.show("等待相机模块初始化", null, MUTED);
        captureCard.show("尚未读取到拍摄请求", null, MUTED);
        diagnostics = deviceSummary() + "\nRoot probe error\n" + error;
        copyButton.setEnabled(true);
    }

    private void finishRefresh() {
        checking = false;
        refreshButton.setEnabled(true);
        refreshButton.setText("检查状态");
    }

    private void openCamera() {
        try {
            Intent camera = getPackageManager().getLaunchIntentForPackage(HdrPolicy.CAMERA);
            if (camera == null) {
                camera = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                        .setPackage(HdrPolicy.CAMERA);
            }
            startActivity(camera);
        } catch (RuntimeException unavailable) {
            Toast.makeText(this, "请从桌面打开系统相机", Toast.LENGTH_SHORT).show();
        }
    }

    private void copyReport() {
        if (diagnostics != null) {
            ClipboardManager clipboard = getSystemService(ClipboardManager.class);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("200MP HDR 诊断", diagnostics));
            }
        }
    }

    private String clock(long millis) {
        return millis == 0 ? "" : DateFormat.getTimeFormat(this).format(new Date(millis));
    }

    private final class StatusCard {
        final LinearLayout layout = column();
        final TextView status = text("", 17, TEXT, true);
        final TextView detail = text("", 13, MUTED, false);

        StatusCard(String title, String initial, String description) {
            layout.setBackground(surface(CARD, BORDER, 16));
            layout.setPadding(dp(16), dp(14), dp(16), dp(14));
            add(layout, text(title, 13, MUTED, true), 0);
            add(layout, status, 7);
            add(layout, detail, 6);
            show(initial, description, MUTED);
        }

        void show(String title, String description, int color) {
            status.setText(title);
            status.setTextColor(color);
            detail.setText(description);
            detail.setVisibility(description == null || description.isEmpty() ? View.GONE : View.VISIBLE);
        }
    }

    private Button button(String label, boolean primary) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(primary ? BACKGROUND : TEXT);
        button.setMinHeight(dp(48));
        button.setPadding(dp(14), dp(10), dp(14), dp(10));
        button.setBackground(new RippleDrawable(
                ColorStateList.valueOf(primary ? 0x30111a1f : 0x30ffffff),
                surface(primary ? GOOD : CARD, primary ? GOOD : BORDER, 12), null));
        return button;
    }

    private TextView text(String label, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        view.setLineSpacing(dp(2), 1f);
        return view;
    }

    private GradientDrawable surface(int fill, int border, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(1), border);
        return drawable;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private void add(LinearLayout parent, View child, int top) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(top);
        parent.addView(child, params);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
